"""Hello World
============

"""
# sphinx_gallery_thumbnail_path = '11_demos/_static/_thumb/demoHelloWorld.png'

print("Hello World")
