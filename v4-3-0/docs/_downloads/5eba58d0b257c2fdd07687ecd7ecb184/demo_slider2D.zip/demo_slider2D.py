"""Slider 2D
============

"""

from itom import ui
# sphinx_gallery_thumbnail_path = '11_demos/_static/_thumb/demoSlider2D.png'

gui = ui("slider2DDemo.ui", ui.TYPEWINDOW, deleteOnClose=True)

gui.show()

###############################################################################
# .. image:: ../../_static/demoSlider2D_1.png
#    :width: 100%
